ALTER TABLE "emergency_logs" DROP CONSTRAINT "emergency_logs_rule_id_emergency_rules_id_fk";
--> statement-breakpoint
ALTER TABLE "emergency_rules" DROP CONSTRAINT "emergency_rules_emergency_class_id_emergency_classes_id_fk";
--> statement-breakpoint
ALTER TABLE "emergency_rules" DROP CONSTRAINT "emergency_rules_policy_id_emergency_policies_id_fk";
--> statement-breakpoint
ALTER TABLE "emergency_events" ALTER COLUMN "emergency_class_id" SET NOT NULL;--> statement-breakpoint
ALTER TABLE "emergency_logs" ALTER COLUMN "triggered_by" SET NOT NULL;--> statement-breakpoint
ALTER TABLE "emergency_logs" ADD COLUMN "emergency_class_id" uuid;--> statement-breakpoint
ALTER TABLE "emergency_logs" ADD COLUMN "policy_id" uuid;--> statement-breakpoint
ALTER TABLE "emergency_policies" ADD COLUMN "emergency_class_id" uuid NOT NULL;--> statement-breakpoint
ALTER TABLE "emergency_logs" ADD CONSTRAINT "emergency_logs_emergency_class_id_emergency_classes_id_fk" FOREIGN KEY ("emergency_class_id") REFERENCES "public"."emergency_classes"("id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "emergency_logs" ADD CONSTRAINT "emergency_logs_policy_id_emergency_policies_id_fk" FOREIGN KEY ("policy_id") REFERENCES "public"."emergency_policies"("id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "emergency_policies" ADD CONSTRAINT "emergency_policies_emergency_class_id_emergency_classes_id_fk" FOREIGN KEY ("emergency_class_id") REFERENCES "public"."emergency_classes"("id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "emergency_logs" DROP COLUMN "rule_id";--> statement-breakpoint
ALTER TABLE "emergency_policies" DROP COLUMN "name";--> statement-breakpoint
ALTER TABLE "emergency_rules" DROP COLUMN "emergency_class_id";--> statement-breakpoint
ALTER TABLE "emergency_rules" DROP COLUMN "policy_id";