CREATE TABLE "emergency_executions" (
	"id" uuid PRIMARY KEY DEFAULT gen_random_uuid() NOT NULL,
	"clinic_id" uuid NOT NULL,
	"emergency_event_id" uuid,
	"rule_id" uuid,
	"started_at" timestamp DEFAULT now(),
	"finished_at" timestamp,
	"status" text DEFAULT 'RUNNING',
	"result_payload" jsonb
);
