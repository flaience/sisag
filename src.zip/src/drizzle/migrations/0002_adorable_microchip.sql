CREATE TABLE "emergency_logs" (
	"id" uuid PRIMARY KEY DEFAULT gen_random_uuid() NOT NULL,
	"clinic_id" uuid NOT NULL,
	"emergency_type_id" uuid,
	"rule_id" uuid,
	"policy_id" uuid,
	"triggered_by" text,
	"status" text DEFAULT 'PENDING',
	"payload" jsonb,
	"created_at" timestamp DEFAULT now()
);
--> statement-breakpoint
CREATE TABLE "emergency_policies" (
	"id" uuid PRIMARY KEY DEFAULT gen_random_uuid() NOT NULL,
	"clinic_id" uuid NOT NULL,
	"emergency_type_id" uuid,
	"action_type" text NOT NULL,
	"max_delay_minutes" integer,
	"notify_channels" text[],
	"is_active" boolean DEFAULT true,
	"created_at" timestamp DEFAULT now()
);
--> statement-breakpoint
CREATE TABLE "emergency_rules" (
	"id" uuid PRIMARY KEY DEFAULT gen_random_uuid() NOT NULL,
	"clinic_id" uuid NOT NULL,
	"name" text NOT NULL,
	"enabled" boolean DEFAULT true,
	"config" jsonb NOT NULL,
	"created_at" timestamp DEFAULT now(),
	"updated_at" timestamp DEFAULT now()
);
--> statement-breakpoint
ALTER TABLE "emergency_events" ALTER COLUMN "clinic_id" DROP NOT NULL;--> statement-breakpoint
ALTER TABLE "emergency_events" ADD COLUMN "emergency_class_id" uuid;--> statement-breakpoint
ALTER TABLE "emergency_events" ADD COLUMN "triggered_by_user" uuid;--> statement-breakpoint
ALTER TABLE "emergency_types" ADD COLUMN "code" text NOT NULL;--> statement-breakpoint
ALTER TABLE "emergency_types" ADD COLUMN "severity_level" integer NOT NULL;--> statement-breakpoint
ALTER TABLE "emergency_policies" ADD CONSTRAINT "emergency_policies_emergency_type_id_emergency_types_id_fk" FOREIGN KEY ("emergency_type_id") REFERENCES "public"."emergency_types"("id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "emergency_events" DROP COLUMN "patient_id";--> statement-breakpoint
ALTER TABLE "emergency_events" DROP COLUMN "emergency_type_id";--> statement-breakpoint
ALTER TABLE "emergency_events" DROP COLUMN "status";--> statement-breakpoint
ALTER TABLE "emergency_types" DROP COLUMN "priority";--> statement-breakpoint
ALTER TABLE "emergency_types" DROP COLUMN "can_override_schedule";--> statement-breakpoint
ALTER TABLE "emergency_types" DROP COLUMN "notify_doctor";--> statement-breakpoint
ALTER TABLE "emergency_types" DROP COLUMN "block_schedule_minutes";--> statement-breakpoint
ALTER TABLE "emergency_types" DROP COLUMN "trigger_n8n_webhook";