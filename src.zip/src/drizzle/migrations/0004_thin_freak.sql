CREATE TABLE "emergency_classes" (
	"id" uuid PRIMARY KEY DEFAULT gen_random_uuid() NOT NULL,
	"clinic_id" uuid NOT NULL,
	"name" text NOT NULL,
	"level" integer NOT NULL,
	"color" text,
	"description" text,
	"created_at" timestamp DEFAULT now()
);
--> statement-breakpoint
ALTER TABLE "emergency_executions" DISABLE ROW LEVEL SECURITY;--> statement-breakpoint
ALTER TABLE "emergency_types" DISABLE ROW LEVEL SECURITY;--> statement-breakpoint
DROP TABLE "emergency_executions" CASCADE;--> statement-breakpoint
DROP TABLE "emergency_types" CASCADE;--> statement-breakpoint
ALTER TABLE "emergency_policies" DROP CONSTRAINT "emergency_policies_emergency_type_id_emergency_types_id_fk";
--> statement-breakpoint
ALTER TABLE "emergency_events" ALTER COLUMN "clinic_id" SET NOT NULL;--> statement-breakpoint
ALTER TABLE "emergency_rules" ALTER COLUMN "name" SET DATA TYPE varchar(255);--> statement-breakpoint
ALTER TABLE "emergency_policies" ADD COLUMN "name" text NOT NULL;--> statement-breakpoint
ALTER TABLE "emergency_rules" ADD COLUMN "emergency_class_id" uuid NOT NULL;--> statement-breakpoint
ALTER TABLE "emergency_rules" ADD COLUMN "policy_id" uuid NOT NULL;--> statement-breakpoint
ALTER TABLE "emergency_events" ADD CONSTRAINT "emergency_events_emergency_class_id_emergency_classes_id_fk" FOREIGN KEY ("emergency_class_id") REFERENCES "public"."emergency_classes"("id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "emergency_logs" ADD CONSTRAINT "emergency_logs_rule_id_emergency_rules_id_fk" FOREIGN KEY ("rule_id") REFERENCES "public"."emergency_rules"("id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "emergency_rules" ADD CONSTRAINT "emergency_rules_emergency_class_id_emergency_classes_id_fk" FOREIGN KEY ("emergency_class_id") REFERENCES "public"."emergency_classes"("id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "emergency_rules" ADD CONSTRAINT "emergency_rules_policy_id_emergency_policies_id_fk" FOREIGN KEY ("policy_id") REFERENCES "public"."emergency_policies"("id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "emergency_logs" DROP COLUMN "emergency_type_id";--> statement-breakpoint
ALTER TABLE "emergency_logs" DROP COLUMN "policy_id";--> statement-breakpoint
ALTER TABLE "emergency_policies" DROP COLUMN "emergency_type_id";