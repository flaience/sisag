DROP TABLE "appointments" CASCADE;--> statement-breakpoint
DROP TABLE "clinics" CASCADE;--> statement-breakpoint
DROP TABLE "doctors" CASCADE;--> statement-breakpoint
DROP TABLE "event_logs" CASCADE;--> statement-breakpoint
DROP TABLE "patients" CASCADE;--> statement-breakpoint
DROP TABLE "payments" CASCADE;--> statement-breakpoint
DROP TABLE "profiles" CASCADE;--> statement-breakpoint
DROP TABLE "tenants" CASCADE;--> statement-breakpoint
DROP TABLE "visit_types" CASCADE;--> statement-breakpoint
DROP TABLE "visits" CASCADE;