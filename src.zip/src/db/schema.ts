import {
  pgTable,
  uuid,
  text,
  timestamp,
  date,
  boolean,
  numeric,
  integer,
  jsonb,
} from "drizzle-orm/pg-core";

/* ============================
   TENANTS
============================ */
export const tenants = pgTable("tenants", {
  id: uuid("id").defaultRandom().primaryKey(),
  name: text("name").notNull(),
  cnpj: text("cnpj").notNull(),
  contactName: text("contact_name"),
  contactEmail: text("contact_email"),
  contactPhone: text("contact_phone"),
  ativo: boolean("ativo").default(true),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

/* ============================
   CLINICS
============================ */
export const clinics = pgTable("clinics", {
  id: uuid("id").defaultRandom().primaryKey(),
  tenantId: uuid("tenant_id").references(() => tenants.id),
  name: text("name").notNull(),
  document: text("document"),
  address: text("address"),
  phone: text("phone"),
  email: text("email"),
  createdAt: timestamp("created_at").defaultNow(),
});

/* ============================
   PROFILES
============================ */
export const profiles = pgTable("profiles", {
  id: uuid("id").primaryKey(),
  tenantId: uuid("tenant_id").references(() => tenants.id),
  clinicId: uuid("clinic_id").references(() => clinics.id),
  role: text("role").default("admin"),
  name: text("name"),
  createdAt: timestamp("created_at").defaultNow(),
});

/* ============================
   DOCTORS
============================ */
export const doctors = pgTable("doctors", {
  id: uuid("id").defaultRandom().primaryKey(),
  clinicId: uuid("clinic_id").references(() => clinics.id),
  name: text("name").notNull(),
  specialty: text("specialty"),
  photoUrl: text("photo_url"),
  status: text("status").default("ACTIVE"),
  avgDuration: integer("avg_duration").default(20),
  createdAt: timestamp("created_at").defaultNow(),
});

/* ============================
   PATIENTS
============================ */
export const patients = pgTable("patients", {
  id: uuid("id").defaultRandom().primaryKey(),
  clinicId: uuid("clinic_id").references(() => clinics.id),
  name: text("name").notNull(),
  phone: text("phone"),
  birthDate: date("birth_date"),
  email: text("email"),
  notes: text("notes"),
  createdAt: timestamp("created_at").defaultNow(),
});

/* ============================
   VISIT TYPES
============================ */
export const visitTypes = pgTable("visit_types", {
  id: uuid("id").defaultRandom().primaryKey(),
  clinicId: uuid("clinic_id").references(() => clinics.id),
  name: text("name").notNull(),
  description: text("description"),
  active: boolean("active").default(true),
  createdAt: timestamp("created_at").defaultNow(),
});

/* ============================
   VISITS
============================ */
export const visits = pgTable("visits", {
  id: uuid("id").defaultRandom().primaryKey(),
  clinicId: uuid("clinic_id").references(() => clinics.id),
  doctorId: uuid("doctor_id").references(() => doctors.id),
  visitTypeId: uuid("visit_type_id").references(() => visitTypes.id),
  visitorName: text("visitor_name"),
  arrivedAt: timestamp("arrived_at").defaultNow(),
  status: text("status").default("CHECKED_IN"),
  createdAt: timestamp("created_at").defaultNow(),
});

/* ============================
   APPOINTMENTS
============================ */
export const appointments = pgTable("appointments", {
  id: uuid("id").defaultRandom().primaryKey(),
  clinicId: uuid("clinic_id").references(() => clinics.id),
  doctorId: uuid("doctor_id").references(() => doctors.id),
  patientId: uuid("patient_id").references(() => patients.id),
  scheduledTime: timestamp("scheduled_time").notNull(),
  confirmedAt: timestamp("confirmed_at"),
  status: text("status").default("PENDING"),
  createdAt: timestamp("created_at").defaultNow(),
});

/* ============================
   PAYMENTS
============================ */
export const payments = pgTable("payments", {
  id: uuid("id").defaultRandom().primaryKey(),
  tenantId: uuid("tenant_id").references(() => tenants.id),
  valor: numeric("valor", { precision: 10, scale: 2 }).notNull(),
  dataVencimento: date("data_vencimento").notNull(),
  dataPagamento: date("data_pagamento"),
  status: text("status").default("PENDING"),
  metodoPagamento: text("metodo_pagamento"),
  createdAt: timestamp("created_at").defaultNow(),
});

/* ============================
   EVENT LOGS
============================ */
export const eventLogs = pgTable("event_logs", {
  id: integer("id").primaryKey().generatedAlwaysAsIdentity(),
  clinicId: uuid("clinic_id").references(() => clinics.id),
  eventType: text("event_type").notNull(),
  doctorId: uuid("doctor_id").references(() => doctors.id),
  patientId: uuid("patient_id").references(() => patients.id),
  payload: jsonb("payload"),
  createdAt: timestamp("created_at").defaultNow(),
});
