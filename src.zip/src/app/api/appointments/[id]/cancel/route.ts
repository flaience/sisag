import { db } from "@/lib/db";
import { appointments } from "@/drizzle/schema";
import { eq } from "drizzle-orm";

export async function PATCH(
  req: Request,
  { params }: { params: { id: string } }
) {
  await db
    .update(appointments)
    .set({ status: "CANCELLED" })
    .where(eq(appointments.id, params.id));

  return Response.json({ success: true });
}
