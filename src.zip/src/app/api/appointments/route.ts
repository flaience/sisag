import { db } from "@/lib/db";
import { appointments } from "@/drizzle/schema";
import { NextResponse } from "next/server";

export async function POST(req: Request) {
  const body = await req.json();

  const created = await db
    .insert(appointments)
    .values({
      clinicId: body.clinicId,
      doctorId: body.doctorId,
      patientId: body.patientId,
      scheduledTime: new Date(body.scheduledTime),
      status: "CONFIRMED",
    })
    .returning();

  return NextResponse.json(created[0]);
}

export async function GET() {
  const items = await db.select().from(appointments);
  return NextResponse.json(items);
}
