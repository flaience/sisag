import { NextResponse } from "next/server";
import { db } from "@/lib/db";
import {
  doctorSchedules,
  schedulingConfig,
  appointments,
} from "@/drizzle/schema";
import { eq } from "drizzle-orm";

export async function GET(req: Request) {
  const { searchParams } = new URL(req.url);

  const doctorId = searchParams.get("doctorId")!;
  const date = searchParams.get("date")!; // YYYY-MM-DD

  const day = new Date(date).getDay();

  const schedules = await db
    .select()
    .from(doctorSchedules)
    .where(eq(doctorSchedules.doctorId, doctorId));

  const config = await db.select().from(schedulingConfig).limit(1);

  const slotDuration = config[0]?.slotDurationMinutes ?? 15;
  const buffer = config[0]?.bufferMinutes ?? 0;

  // Buscar consultas existentes
  const existing = await db
    .select()
    .from(appointments)
    .where(eq(appointments.doctorId, doctorId));

  const takenTimes = new Set(
    existing.map((e) => new Date(e.scheduledTime).toISOString())
  );

  const result: string[] = [];

  for (const sch of schedules.filter((s) => s.weekday === day)) {
    let current = sch.startTime;

    while (current < sch.endTime) {
      const timeIso = `${date}T${current}:00.000Z`;

      if (!takenTimes.has(timeIso)) {
        result.push(current);
      }

      const [h, m] = current.split(":").map(Number);
      const next = new Date();
      next.setHours(h, m + slotDuration + buffer);

      current = next.toTimeString().slice(0, 5);
    }
  }

  return NextResponse.json({ slots: result });
}
