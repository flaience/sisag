import { NextResponse } from "next/server";
import { db } from "@/lib/db";
import { schedulingConfig } from "@/drizzle/schema";
import { eq } from "drizzle-orm";

export async function GET() {
  const config = await db.select().from(schedulingConfig).limit(1);
  return NextResponse.json(config[0] ?? {});
}

export async function POST(req: Request) {
  const body = await req.json();

  await db.insert(schedulingConfig).values(body).onConflictDoNothing();

  return NextResponse.json({ ok: true });
}
