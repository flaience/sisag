import { NextResponse } from "next/server";
import { db } from "@/lib/db";
import { appointments } from "@/drizzle/schema";
import { eq } from "drizzle-orm";

export async function GET() {
  const data = await db.select().from(appointments);
  return NextResponse.json(data);
}

export async function POST(req: Request) {
  const body = await req.json();

  const created = await db.insert(appointments).values({
    clinicId: body.clinicId,
    doctorId: body.doctorId,
    patientId: body.patientId,
    scheduledTime: new Date(body.scheduledTime),
    status: "PENDING",
  });

  return NextResponse.json({ success: true });
}
