import { NextResponse } from "next/server";
import { db } from "@/lib/db";
import { schedulingConfig } from "@/drizzle/schema";

export async function GET() {
  const data = await db.select().from(schedulingConfig);
  return NextResponse.json(data);
}

export async function POST(req: Request) {
  const body = await req.json();

  await db.insert(schedulingConfig).values({
    clinicId: body.clinicId,
    slotDurationMinutes: body.slotDurationMinutes,
    bufferMinutes: body.bufferMinutes,
    allowOverbooking: body.allowOverbooking,
    maxAdvanceDays: body.maxAdvanceDays,
  });

  return NextResponse.json({ success: true });
}
