import { NextResponse } from "next/server";
import { db } from "@/lib/db";
import { doctorSchedules } from "@/drizzle/schema";
import { eq } from "drizzle-orm";

export async function GET() {
  const data = await db.select().from(doctorSchedules);
  return NextResponse.json(data);
}

export async function POST(req: Request) {
  const body = await req.json();

  await db.insert(doctorSchedules).values({
    doctorId: body.doctorId,
    weekday: body.weekday,
    startTime: body.startTime,
    endTime: body.endTime,
  });

  return NextResponse.json({ success: true });
}
