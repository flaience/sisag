import { db } from "@/lib/db";
import {
  doctorSchedules,
  schedulingConfig,
  appointments,
} from "@/drizzle/schema";
import { and, eq, gte, lte } from "drizzle-orm";
import { NextResponse } from "next/server";

function toMinutes(h: string) {
  const [hh, mm] = h.split(":").map(Number);
  return hh * 60 + mm;
}

function toTime(m: number) {
  const h = Math.floor(m / 60);
  const mi = m % 60;
  return `${String(h).padStart(2, "0")}:${String(mi).padStart(2, "0")}`;
}

export async function GET(
  req: Request,
  { params }: { params: { id: string } }
) {
  const url = new URL(req.url);
  const date = url.searchParams.get("date");

  if (!date)
    return NextResponse.json({ error: "date required" }, { status: 400 });

  const weekday = new Date(date).getDay();

  const [config] = await db.select().from(schedulingConfig).limit(1);

  const schedules = await db
    .select()
    .from(doctorSchedules)
    .where(eq(doctorSchedules.doctorId, params.id));

  const todays = schedules.filter((s) => s.weekday === weekday);

  const appts = await db
    .select()
    .from(appointments)
    .where(
      and(
        eq(appointments.doctorId, params.id),
        gte(appointments.scheduledTime, new Date(`${date}T00:00:00`)),
        lte(appointments.scheduledTime, new Date(`${date}T23:59:59`))
      )
    );

  const duration = config?.slotDurationMinutes ?? 15;

  const slots: any[] = [];

  for (const b of todays) {
    let cur = toMinutes(b.startTime);
    const end = toMinutes(b.endTime);

    while (cur + duration <= end) {
      const exists = appts.find((a) => {
        const m =
          new Date(a.scheduledTime).getHours() * 60 +
          new Date(a.scheduledTime).getMinutes();
        return m === cur;
      });

      if (!exists) {
        slots.push({
          start: toTime(cur),
          end: toTime(cur + duration),
        });
      }

      cur += duration;
    }
  }

  return NextResponse.json(slots);
}
