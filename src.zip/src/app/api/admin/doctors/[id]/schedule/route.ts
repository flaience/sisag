import { db } from "@/lib/db";
import { doctorSchedules } from "@/drizzle/schema";
import { NextResponse } from "next/server";
import { eq } from "drizzle-orm";

export async function GET(_: Request, { params }: { params: { id: string } }) {
  const items = await db
    .select()
    .from(doctorSchedules)
    .where(eq(doctorSchedules.doctorId, params.id));

  return NextResponse.json(items);
}

export async function POST(
  req: Request,
  { params }: { params: { id: string } }
) {
  const body = await req.json();

  await db.insert(doctorSchedules).values({
    doctorId: params.id,
    ...body,
  });

  return NextResponse.json({ ok: true });
}
