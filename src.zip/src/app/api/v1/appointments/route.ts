import { NextResponse } from "next/server";
import { db } from "@/lib/db";
import { appointments } from "@/drizzle/schema";
import { z } from "zod";

const CreateAppointmentSchema = z.object({
  clinicId: z.string().uuid(),
  doctorId: z.string().uuid(),
  patientId: z.string().uuid(),
  scheduledTime: z.string().datetime(),
});

export async function GET() {
  const data = await db
    .select()
    .from(appointments)
    .orderBy(appointments.scheduledTime);

  return NextResponse.json(data);
}

export async function POST(req: Request) {
  try {
    const body = await req.json();
    const data = CreateAppointmentSchema.parse(body);

    const created = await db
      .insert(appointments)
      .values({
        ...data,
        scheduledTime: new Date(data.scheduledTime),
      })
      .returning();

    return NextResponse.json(created[0], { status: 201 });
  } catch (err: any) {
    return NextResponse.json(
      { error: err?.errors ?? "Erro ao criar agendamento" },
      { status: 400 }
    );
  }
}
