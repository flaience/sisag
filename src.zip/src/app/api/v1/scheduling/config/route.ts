import { NextResponse } from "next/server";
import { db } from "@/lib/db";
import { schedulingConfig } from "@/drizzle/schema";
import { eq } from "drizzle-orm";

export async function GET() {
  try {
    const config = await db.select().from(schedulingConfig).limit(1);
    return NextResponse.json(config[0] ?? null);
  } catch (err) {
    console.error(err);
    return NextResponse.json(
      { error: "Erro ao carregar config" },
      { status: 500 }
    );
  }
}

export async function POST(req: Request) {
  try {
    const body = await req.json();

    const {
      clinicId,
      slotDurationMinutes,
      bufferMinutes,
      allowOverbooking,
      maxAdvanceDays,
    } = body;

    // Verifica se já existe config
    const existing = await db
      .select()
      .from(schedulingConfig)
      .where(eq(schedulingConfig.clinicId, clinicId))
      .limit(1);

    if (existing.length === 0) {
      // INSERT
      await db.insert(schedulingConfig).values({
        clinicId,
        slotDurationMinutes,
        bufferMinutes,
        allowOverbooking,
        maxAdvanceDays,
      });
    } else {
      // UPDATE
      await db
        .update(schedulingConfig)
        .set({
          slotDurationMinutes,
          bufferMinutes,
          allowOverbooking,
          maxAdvanceDays,
        })
        .where(eq(schedulingConfig.clinicId, clinicId));
    }

    return NextResponse.json({ success: true });
  } catch (error) {
    console.error(error);
    return NextResponse.json(
      { error: "Erro ao salvar config" },
      { status: 500 }
    );
  }
}
