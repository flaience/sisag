"use client";

import { zodResolver } from "@hookform/resolvers/zod";
import { useForm } from "react-hook-form";
import { PatientSchema, PatientFormData } from "../schema";

import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";

import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";

import { createPatient, updatePatient } from "../actions/patient-actions";
import { toast } from "sonner";
import { useEffect } from "react";

interface PatientsFormProps {
  initial?: PatientFormData | null;
  onSaved: () => void;
  onClose: () => void;
}

export default function PatientsForm({
  initial,
  onSaved,
  onClose,
}: PatientsFormProps) {
  const form = useForm<PatientFormData>({
    resolver: zodResolver(PatientSchema),
    defaultValues: initial ?? {
      name: "",
      phone: "",
      email: "",
      birth_date: "",
    },
  });

  // Atualiza os valores quando editar
  useEffect(() => {
    if (initial) {
      form.reset(initial);
    }
  }, [initial, form]);

  async function onSubmit(values: PatientFormData) {
    try {
      if (values.id) {
        await updatePatient(values);
        toast.success("Paciente atualizado com sucesso!");
      } else {
        await createPatient(values);
        toast.success("Paciente criado com sucesso!");
      }

      onSaved();
      onClose();
    } catch (error: any) {
      toast.error("Erro ao salvar paciente");
      console.error(error);
    }
  }

  return (
    <Form {...form}>
      <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
        {/* Nome */}
        <FormField
          control={form.control}
          name="name"
          render={({ field }) => (
            <FormItem>
              <FormLabel>Nome</FormLabel>
              <FormControl>
                <Input placeholder="Nome completo" {...field} />
              </FormControl>
              <FormMessage />
            </FormItem>
          )}
        />

        {/* Telefone */}
        <FormField
          control={form.control}
          name="phone"
          render={({ field }) => (
            <FormItem>
              <FormLabel>Telefone</FormLabel>
              <FormControl>
                <Input
                  placeholder="(00) 00000-0000"
                  {...field}
                  value={field.value ?? ""}
                />
              </FormControl>
              <FormMessage />
            </FormItem>
          )}
        />

        {/* Email */}
        <FormField
          control={form.control}
          name="email"
          render={({ field }) => (
            <FormItem>
              <FormLabel>E-mail</FormLabel>
              <FormControl>
                <Input
                  placeholder="nome@exemplo.com"
                  {...field}
                  value={field.value ?? ""}
                />
              </FormControl>
              <FormMessage />
            </FormItem>
          )}
        />

        {/* Data de Nascimento */}
        <FormField
          control={form.control}
          name="birth_date"
          render={({ field }) => (
            <FormItem>
              <FormLabel>Data de nascimento</FormLabel>
              <FormControl>
                <Input type="date" {...field} value={field.value ?? ""} />
              </FormControl>
              <FormMessage />
            </FormItem>
          )}
        />

        {/* Botões */}
        <div className="flex justify-end gap-2 pt-2">
          <Button type="button" variant="outline" onClick={onClose}>
            Cancelar
          </Button>

          <Button type="submit">
            {initial?.id ? "Salvar alterações" : "Criar paciente"}
          </Button>
        </div>
      </form>
    </Form>
  );
}
