// src/app/admin/pacientes/components/PatientsTable.tsx
"use client";

import { useEffect, useState } from "react";
import { listPatients, deletePatient } from "../actions/patient-actions";
import { toast } from "sonner";

interface Patient {
  id: string;
  name: string;
  phone?: string | null;
  email?: string | null;
  birth_date?: string | null;
}

export default function PatientsTable({
  onEdit,
}: {
  onEdit: (p: Patient) => void;
}) {
  const [items, setItems] = useState<Patient[]>([]);
  const [loading, setLoading] = useState(false);
  const [page, setPage] = useState(1);
  const [total, setTotal] = useState(0);
  const [search, setSearch] = useState("");

  async function load() {
    setLoading(true);
    try {
      const data = await listPatients({ page, limit: 10, search });
      setItems(data.items);
      setTotal(data.total);
    } catch (err: any) {
      toast.error("Erro ao carregar pacientes");
      console.error(err);
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => {
    load();
  }, [page, search]);

  async function handleDelete(id: string) {
    if (!confirm("Confirmar exclusão do paciente?")) return;
    try {
      await deletePatient(id);
      toast.success("Paciente removido");
      load();
    } catch (err) {
      toast.error("Erro ao remover paciente");
      console.error(err);
    }
  }

  const totalPages = Math.max(1, Math.ceil(total / 10));

  return (
    <div className="bg-white p-4 rounded-xl shadow">
      <div className="flex items-center gap-2 mb-4">
        <input
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          placeholder="Buscar por nome, e-mail ou telefone"
          className="border p-2 rounded flex-1"
        />
        <button
          onClick={() => {
            setPage(1);
            load();
          }}
          className="bg-primary text-white px-4 py-2 rounded"
        >
          Buscar
        </button>
      </div>

      {loading ? (
        <div className="p-8 text-center">Carregando...</div>
      ) : (
        <table className="w-full">
          <thead className="bg-gray-100">
            <tr>
              <th className="text-left px-4 py-2">Nome</th>
              <th className="text-left px-4 py-2">Telefone</th>
              <th className="text-left px-4 py-2">E-mail</th>
              <th className="text-left px-4 py-2">Nascimento</th>
              <th className="text-right px-4 py-2">Ações</th>
            </tr>
          </thead>
          <tbody>
            {items.length === 0 && (
              <tr>
                <td colSpan={5} className="p-6 text-center text-gray-500">
                  Nenhum paciente encontrado
                </td>
              </tr>
            )}
            {items.map((p) => (
              <tr key={p.id} className="border-b">
                <td className="px-4 py-2">{p.name}</td>
                <td className="px-4 py-2">{p.phone ?? "—"}</td>
                <td className="px-4 py-2">{p.email ?? "—"}</td>
                <td className="px-4 py-2">
                  {p.birth_date
                    ? new Date(p.birth_date).toLocaleDateString("pt-BR")
                    : "—"}
                </td>
                <td className="px-4 py-2 text-right">
                  <button
                    onClick={() => onEdit(p)}
                    className="mr-2 px-3 py-1 border rounded"
                  >
                    Editar
                  </button>
                  <button
                    onClick={() => handleDelete(p.id)}
                    className="px-3 py-1 bg-red-600 text-white rounded"
                  >
                    Excluir
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      )}

      <div className="flex items-center justify-between mt-4">
        <div className="text-sm text-gray-600">
          Página {page} de {totalPages} ({total} itens)
        </div>
        <div className="flex gap-2">
          <button
            onClick={() => setPage((p) => Math.max(1, p - 1))}
            disabled={page === 1}
            className="px-3 py-1 border rounded disabled:opacity-50"
          >
            Anterior
          </button>
          <button
            onClick={() => setPage((p) => Math.min(totalPages, p + 1))}
            disabled={page >= totalPages}
            className="px-3 py-1 border rounded disabled:opacity-50"
          >
            Próxima
          </button>
        </div>
      </div>
    </div>
  );
}
