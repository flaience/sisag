"use client";

import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";

import PatientsForm from "./patientsForm";

interface Patient {
  id?: string;
  name: string;
  phone?: string;
  email?: string;
  birth_date?: string;
}

export default function PatientsDialog({
  open,
  onOpenChange,
  editing,
  onSaved,
}: {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  editing: Patient | null;
  onSaved: () => void;
}) {
  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-xl">
        <DialogHeader>
          <DialogTitle>
            {editing ? "Editar paciente" : "Novo paciente"}
          </DialogTitle>
        </DialogHeader>

        <PatientsForm
          initial={editing}
          onSaved={onSaved}
          onClose={() => onOpenChange(false)}
        />
      </DialogContent>
    </Dialog>
  );
}
