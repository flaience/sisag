// src/app/admin/pacientes/actions/patient-actions.ts
export const API_BASE = "/api/admin/patients";

export async function listPatients({ page = 1, limit = 20, search = "" } = {}) {
  const q = new URLSearchParams({ page: String(page), limit: String(limit) });
  if (search) q.set("search", search);
  const res = await fetch(`${API_BASE}?${q.toString()}`, { cache: "no-store" });
  if (!res.ok) throw new Error("Erro ao buscar pacientes");
  return res.json();
}

export async function createPatient(payload: any) {
  const res = await fetch(API_BASE, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(payload),
  });
  if (!res.ok) {
    const txt = await res.text();
    throw new Error(txt || "Erro ao criar paciente");
  }
  return res.json();
}

export async function updatePatient(payload: any) {
  const res = await fetch(API_BASE, {
    method: "PUT",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(payload),
  });
  if (!res.ok) {
    const txt = await res.text();
    throw new Error(txt || "Erro ao atualizar paciente");
  }
  return res.json();
}

export async function deletePatient(id: string) {
  const res = await fetch(`${API_BASE}?id=${id}`, { method: "DELETE" });
  if (!res.ok) {
    const txt = await res.text();
    throw new Error(txt || "Erro ao deletar paciente");
  }
  return res.json();
}
