// src/app/admin/pacientes/[id]/edit/page.tsx
"use client";
import { useRouter, useParams } from "next/navigation";
import { useEffect, useState } from "react";
import { isoToInputValue, brToIso } from "@/lib/dateFormat";

export default function EditPatientPage() {
  const router = useRouter();
  const params = useParams();
  const id = (params as any)?.id;
  const [loading, setLoading] = useState(true);
  const [name, setName] = useState("");
  const [phone, setPhone] = useState("");
  const [email, setEmail] = useState("");
  const [birthDate, setBirthDate] = useState("");
  const [notes, setNotes] = useState("");
  const [err, setErr] = useState("");

  useEffect(() => {
    async function load() {
      setLoading(true);
      const res = await fetch("/api/pacientes");
      const list = await res.json();
      const p = list.find((x: any) => x.id === id);
      if (p) {
        setName(p.name);
        setPhone(p.phone ?? "");
        setEmail(p.email ?? "");
        setBirthDate(p.birth_date ? isoToInputValue(p.birth_date) : "");
        setNotes(p.notes ?? "");
      }
      setLoading(false);
    }
    if (id) load();
  }, [id]);

  async function handleSave(e: any) {
    e.preventDefault();
    setErr("");
    setLoading(true);
    const res = await fetch("/api/pacientes", {
      method: "PUT",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        id,
        name,
        phone,
        email,
        birth_date: brToIso(birthDate),
        notes,
      }),
    });
    const data = await res.json();
    setLoading(false);
    if (res.ok) router.push("/admin/pacientes");
    else setErr(data.error ?? "Erro");
  }

  return (
    <div className="p-6 max-w-2xl">
      <h1 className="text-2xl font-bold mb-4">Editar Paciente</h1>

      {loading ? (
        <p>Carregando...</p>
      ) : (
        <form
          onSubmit={handleSave}
          className="bg-white p-6 rounded shadow flex flex-col gap-4"
        >
          <input
            required
            value={name}
            onChange={(e) => setName(e.target.value)}
            placeholder="Nome"
            className="p-2 border rounded"
          />
          <input
            value={phone}
            onChange={(e) => setPhone(e.target.value)}
            placeholder="Telefone"
            className="p-2 border rounded"
          />
          <input
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            placeholder="E-mail"
            className="p-2 border rounded"
          />
          <input
            type="date"
            value={birthDate}
            onChange={(e) => setBirthDate(e.target.value)}
            className="p-2 border rounded"
          />

          <textarea
            value={notes}
            onChange={(e) => setNotes(e.target.value)}
            placeholder="Observações"
            className="p-2 border rounded"
          />

          {err && <p className="text-red-600">{err}</p>}

          <div className="flex gap-2">
            <button
              disabled={loading}
              className="bg-blue-600 text-white px-4 py-2 rounded"
            >
              {loading ? "Salvando..." : "Salvar"}
            </button>
            <button
              type="button"
              onClick={() => router.back()}
              className="px-4 py-2 border rounded"
            >
              Cancelar
            </button>
          </div>
        </form>
      )}
    </div>
  );
}
