import dynamic from "next/dynamic";

const PatientsClient = dynamic(() => import("./PatientsClient"), {
  ssr: false,
});

export default function PatientsPage() {
  return (
    <div>
      <h1 className="text-2xl font-bold text-primary mb-6">Pacientes</h1>
      <PatientsClient />
    </div>
  );
}
