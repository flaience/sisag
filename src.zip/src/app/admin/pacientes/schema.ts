import { z } from "zod";

export const PatientSchema = z.object({
  id: z.string().uuid().optional(),
  name: z.string().min(1, "O nome é obrigatório"),
  phone: z.string().optional().nullable(),
  email: z.string().email("E-mail inválido").optional().nullable(),
  birth_date: z.string().optional().nullable(),
});

export type PatientFormData = z.infer<typeof PatientSchema>;
