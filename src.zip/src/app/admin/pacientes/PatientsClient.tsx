"use client";

import { useState } from "react";
import PatientsTable from "./components/patientsTable";
import PatientsDialog from "./components/PatientsDialog";

export default function PatientsClient() {
  const [open, setOpen] = useState(false);
  const [editing, setEditing] = useState<any | null>(null);
  const [refreshKey, setRefreshKey] = useState(0);

  function handleNew() {
    setEditing(null);
    setOpen(true);
  }

  function onSaved() {
    setRefreshKey((k) => k + 1);
  }

  return (
    <div>
      <div className="mb-4">
        <button
          onClick={handleNew}
          className="bg-primary text-white px-4 py-2 rounded"
        >
          Novo paciente
        </button>
      </div>

      <div key={String(refreshKey)}>
        <PatientsTable
          onEdit={(p) => {
            setEditing(p);
            setOpen(true);
          }}
        />
      </div>

      <PatientsDialog
        open={open}
        onOpenChange={setOpen}
        editing={editing}
        onSaved={onSaved}
      />
    </div>
  );
}
