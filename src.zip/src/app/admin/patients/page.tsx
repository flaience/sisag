"use client";

import { useEffect, useState } from "react";

interface Patient {
  id: string;
  name: string;
  phone?: string;
  email?: string;
  birth_date?: string;
}

export default function PatientsPage() {
  const [patients, setPatients] = useState<Patient[]>([]);
  const [name, setName] = useState("");
  const [phone, setPhone] = useState("");
  const [email, setEmail] = useState("");

  async function fetchPatients() {
    const res = await fetch("/api/admin/patients");
    const data = await res.json();
    setPatients(data);
  }

  async function addPatient() {
    if (!name) return alert("Informe o nome do paciente");

    await fetch("/api/admin/patients", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ name, phone, email }),
    });

    setName("");
    setPhone("");
    setEmail("");
    fetchPatients();
  }

  useEffect(() => {
    fetchPatients();
  }, []);

  return (
    <div>
      <h1 className="text-2xl font-bold text-primary mb-6">Pacientes</h1>

      <div className="bg-white p-4 rounded-xl shadow mb-6">
        <h2 className="font-semibold mb-2">Cadastrar novo</h2>
        <div className="flex gap-2 flex-wrap">
          <input
            type="text"
            value={name}
            onChange={(e) => setName(e.target.value)}
            placeholder="Nome"
            className="border p-2 rounded flex-1 min-w-[180px]"
          />
          <input
            type="text"
            value={phone}
            onChange={(e) => setPhone(e.target.value)}
            placeholder="Telefone"
            className="border p-2 rounded flex-1 min-w-[180px]"
          />
          <input
            type="email"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            placeholder="E-mail"
            className="border p-2 rounded flex-1 min-w-[180px]"
          />
          <button
            onClick={addPatient}
            className="bg-primary text-white px-4 py-2 rounded"
          >
            Adicionar
          </button>
        </div>
      </div>

      <table className="w-full bg-white shadow rounded-xl">
        <thead className="bg-primary text-white">
          <tr>
            <th className="text-left px-4 py-2">Nome</th>
            <th className="text-left px-4 py-2">Telefone</th>
            <th className="text-left px-4 py-2">E-mail</th>
            <th className="text-left px-4 py-2">Nascimento</th>
          </tr>
        </thead>
        <tbody>
          {patients.map((p) => (
            <tr key={p.id} className="border-b">
              <td className="px-4 py-2">{p.name}</td>
              <td className="px-4 py-2">{p.phone ?? "—"}</td>
              <td className="px-4 py-2">{p.email ?? "—"}</td>
              <td className="px-4 py-2">
                {p.birth_date
                  ? new Date(p.birth_date).toLocaleDateString("pt-BR")
                  : "—"}
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}
