// src/app/admin/profissionais/novo/page.tsx
"use client";

import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";

export default function NewDoctorPage() {
  useEffect(() => {
    async function load() {
      const res = await fetch("/api/me");
      const data = await res.json();
      setClinicId(data.clinicId);
    }
    load();
  }, []);
  const [clinicId, setClinicId] = useState<string | null>(null);
  const router = useRouter();
  const [name, setName] = useState("");
  const [specialty, setSpecialty] = useState("");
  const [avgDuration, setAvgDuration] = useState(20);
  const [photoUrl, setPhotoUrl] = useState("");
  const [loading, setLoading] = useState(false);
  const [err, setErr] = useState("");

  async function handleSubmit(e: any) {
    e.preventDefault();
    setLoading(true);
    setErr("");

    const clinicId = document
      .querySelector("[data-clinic-id]")
      ?.getAttribute("data-clinic-id");

    const res = await fetch("/api/profissionais", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        name,
        specialty,
        avg_duration: Number(avgDuration),
        photo_url: photoUrl,
        clinicId: clinicId,
      }),
    });

    const data = await res.json();
    setLoading(false);
    if (res.ok) {
      router.push("/admin/profissionais");
    } else {
      setErr(data.error ?? "Erro ao criar");
    }
  }

  return (
    <div className="p-6 max-w-2xl">
      <h1 className="text-2xl font-bold mb-4">Novo Profissional</h1>
      <form
        onSubmit={handleSubmit}
        className="bg-white p-6 rounded shadow flex flex-col gap-4"
      >
        <input
          required
          value={name}
          onChange={(e) => setName(e.target.value)}
          placeholder="Nome"
          className="p-2 border rounded"
        />
        <input
          value={specialty}
          onChange={(e) => setSpecialty(e.target.value)}
          placeholder="Especialidade"
          className="p-2 border rounded"
        />
        <input
          type="number"
          value={avgDuration}
          onChange={(e) => setAvgDuration(Number(e.target.value))}
          placeholder="Duração média (min)"
          className="p-2 border rounded"
        />
        <input
          value={photoUrl}
          onChange={(e) => setPhotoUrl(e.target.value)}
          placeholder="URL da foto (opcional)"
          className="p-2 border rounded"
        />

        {err && <p className="text-red-600">{err}</p>}

        <div className="flex gap-2">
          <button
            disabled={loading}
            className="bg-blue-600 text-white px-4 py-2 rounded"
          >
            {loading ? "Salvando..." : "Salvar"}
          </button>
          <button
            type="button"
            onClick={() => router.back()}
            className="px-4 py-2 border rounded"
          >
            Cancelar
          </button>
        </div>
      </form>
    </div>
  );
}
