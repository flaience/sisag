// src/app/admin/profissionais/[id]/edit/page.tsx
"use client";
import { useRouter, useParams } from "next/navigation";
import { useEffect, useState } from "react";

export default function EditDoctorPage() {
  const router = useRouter();
  const params = useParams();
  const id = (params as any)?.id;
  const [loading, setLoading] = useState(true);
  const [name, setName] = useState("");
  const [specialty, setSpecialty] = useState("");
  const [avgDuration, setAvgDuration] = useState(20);
  const [photoUrl, setPhotoUrl] = useState("");
  const [err, setErr] = useState("");

  useEffect(() => {
    async function load() {
      setLoading(true);
      const res = await fetch("/api/profissionais");
      const list = await res.json();
      const doc = list.find((d: any) => d.id === id);
      if (doc) {
        setName(doc.name);
        setSpecialty(doc.specialty ?? "");
        setAvgDuration(doc.avg_duration ?? 20);
        setPhotoUrl(doc.photo_url ?? "");
      }
      setLoading(false);
    }
    if (id) load();
  }, [id]);

  async function handleSave(e: any) {
    e.preventDefault();
    setErr("");
    setLoading(true);
    const res = await fetch("/api/profissionais", {
      method: "PUT",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        id,
        name,
        specialty,
        avg_duration: Number(avgDuration),
        photo_url: photoUrl,
      }),
    });
    const data = await res.json();
    setLoading(false);
    if (res.ok) {
      router.push("/admin/profissionais");
    } else {
      setErr(data.error ?? "Erro");
    }
  }

  return (
    <div className="p-6 max-w-2xl">
      <h1 className="text-2xl font-bold mb-4">Editar Profissional</h1>
      {loading ? (
        <p>Carregando...</p>
      ) : (
        <form
          onSubmit={handleSave}
          className="bg-white p-6 rounded shadow flex flex-col gap-4"
        >
          <input
            required
            value={name}
            onChange={(e) => setName(e.target.value)}
            placeholder="Nome"
            className="p-2 border rounded"
          />
          <input
            value={specialty}
            onChange={(e) => setSpecialty(e.target.value)}
            placeholder="Especialidade"
            className="p-2 border rounded"
          />
          <input
            type="number"
            value={avgDuration}
            onChange={(e) => setAvgDuration(Number(e.target.value))}
            placeholder="Duração média (min)"
            className="p-2 border rounded"
          />
          <input
            value={photoUrl}
            onChange={(e) => setPhotoUrl(e.target.value)}
            placeholder="URL da foto (opcional)"
            className="p-2 border rounded"
          />

          {err && <p className="text-red-600">{err}</p>}

          <div className="flex gap-2">
            <button
              disabled={loading}
              className="bg-blue-600 text-white px-4 py-2 rounded"
            >
              {loading ? "Salvando..." : "Salvar"}
            </button>
            <button
              type="button"
              onClick={() => router.back()}
              className="px-4 py-2 border rounded"
            >
              Cancelar
            </button>
          </div>
        </form>
      )}
    </div>
  );
}
