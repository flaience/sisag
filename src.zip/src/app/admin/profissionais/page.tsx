"use client";
// src/app/admin/profissionais/page.tsx
import Link from "next/link";
import { useEffect, useState } from "react";

interface Doctor {
  id: string;
  name: string;
  specialty?: string;
  status?: string;
  avg_duration?: number;
  photo_url?: string;
}

export default function DoctorsPage() {
  const [doctors, setDoctors] = useState<Doctor[]>([]);
  const [loading, setLoading] = useState(false);

  async function fetchDoctors() {
    setLoading(true);
    const res = await fetch("/api/profissionais");
    const data = await res.json();
    setDoctors(data);
    setLoading(false);
  }

  useEffect(() => {
    fetchDoctors();
  }, []);

  async function handleDelete(id: string) {
    if (!confirm("Deseja marcar este profissional como inativo?")) return;
    await fetch(`/api/profissionais?id=${id}`, { method: "DELETE" });
    fetchDoctors();
  }

  return (
    <div className="p-6">
      <div className="flex justify-between items-center mb-6">
        <h1 className="text-2xl font-bold">Profissionais</h1>
        <Link
          href="/admin/profissionais/novo"
          className="btn-primary px-4 py-2 rounded"
        >
          Novo Profissional
        </Link>
      </div>

      {loading ? (
        <p>Carregando...</p>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {doctors.map((d) => (
            <div
              key={d.id}
              className="bg-white p-4 rounded shadow flex items-center gap-4"
            >
              <img
                src={d.photo_url ?? "/img/doctor-placeholder.png"}
                alt={d.name}
                className="w-16 h-16 rounded-full object-cover"
              />
              <div className="flex-1">
                <div className="font-semibold">{d.name}</div>
                <div className="text-sm text-muted-foreground">
                  {d.specialty}
                </div>
                <div className="text-sm text-slate-500">
                  Duração média: {d.avg_duration ?? 20} min
                </div>
              </div>
              <div className="flex flex-col gap-2">
                <Link
                  href={`/admin/profissionais/${d.id}/edit`}
                  className="text-sm text-blue-600"
                >
                  Editar
                </Link>
                <button
                  onClick={() => handleDelete(d.id)}
                  className="text-sm text-red-600"
                >
                  Inativar
                </button>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
