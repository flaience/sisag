"use client";

import { useEffect, useState } from "react";

interface Appointment {
  id: string;
  doctor: { id: string; name: string };
  patient: { id: string; name: string };
  scheduled_time: string;
  status: string;
}

interface Doctor {
  id: string;
  name: string;
}

interface Patient {
  id: string;
  name: string;
}

export default function AppointmentsPage() {
  const [appointments, setAppointments] = useState<Appointment[]>([]);
  const [doctors, setDoctors] = useState<Doctor[]>([]);
  const [patients, setPatients] = useState<Patient[]>([]);
  const [doctorId, setDoctorId] = useState("");
  const [patientId, setPatientId] = useState("");
  const [dateTime, setDateTime] = useState("");
  const [editingId, setEditingId] = useState<string | null>(null);

  async function fetchData() {
    const [a, d, p] = await Promise.all([
      fetch("/api/admin/appointments").then((r) => r.json()),
      fetch("/api/admin/doctors").then((r) => r.json()),
      fetch("/api/admin/patients").then((r) => r.json()),
    ]);
    setAppointments(a);
    setDoctors(d);
    setPatients(p);
  }

  async function addOrUpdateAppointment() {
    if (!doctorId || !patientId || !dateTime)
      return alert("Preencha todos os campos");

    const method = editingId ? "PUT" : "POST";
    await fetch("/api/admin/appointments", {
      method,
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        id: editingId,
        doctorId,
        patientId,
        scheduled_time: dateTime,
      }),
    });

    resetForm();
    fetchData();
  }

  async function deleteAppointment(id: string) {
    if (!confirm("Deseja realmente cancelar este agendamento?")) return;
    await fetch(`/api/admin/appointments?id=${id}`, { method: "DELETE" });
    fetchData();
  }

  function startEdit(a: Appointment) {
    setEditingId(a.id);
    setDoctorId(a.doctor.id);
    setPatientId(a.patient.id);
    setDateTime(a.scheduled_time.slice(0, 16)); // formato compatível com input datetime-local
  }

  function resetForm() {
    setEditingId(null);
    setDoctorId("");
    setPatientId("");
    setDateTime("");
  }

  useEffect(() => {
    fetchData();
  }, []);

  return (
    <div>
      <h1 className="text-2xl font-bold text-primary mb-6">Agendamentos</h1>

      <div className="bg-white p-4 rounded-xl shadow mb-6">
        <h2 className="font-semibold mb-2">
          {editingId ? "Editar agendamento" : "Cadastrar novo agendamento"}
        </h2>
        <div className="flex flex-wrap gap-2 items-center">
          <select
            value={doctorId}
            onChange={(e) => setDoctorId(e.target.value)}
            className="border p-2 rounded min-w-[180px]"
          >
            <option value="">Profissional</option>
            {doctors.map((d) => (
              <option key={d.id} value={d.id}>
                {d.name}
              </option>
            ))}
          </select>

          <select
            value={patientId}
            onChange={(e) => setPatientId(e.target.value)}
            className="border p-2 rounded min-w-[180px]"
          >
            <option value="">Paciente</option>
            {patients.map((p) => (
              <option key={p.id} value={p.id}>
                {p.name}
              </option>
            ))}
          </select>

          <input
            type="datetime-local"
            value={dateTime}
            onChange={(e) => setDateTime(e.target.value)}
            className="border p-2 rounded min-w-[220px]"
          />

          <button
            onClick={addOrUpdateAppointment}
            className="bg-primary text-white px-4 py-2 rounded"
          >
            {editingId ? "Salvar alterações" : "Adicionar"}
          </button>

          {editingId && (
            <button
              onClick={resetForm}
              className="bg-gray-400 text-white px-4 py-2 rounded"
            >
              Cancelar edição
            </button>
          )}
        </div>
      </div>

      <table className="w-full bg-white shadow rounded-xl">
        <thead className="bg-primary text-white">
          <tr>
            <th className="text-left px-4 py-2">Profissional</th>
            <th className="text-left px-4 py-2">Paciente</th>
            <th className="text-left px-4 py-2">Data e Hora</th>
            <th className="text-left px-4 py-2">Status</th>
            <th className="text-left px-4 py-2">Ações</th>
          </tr>
        </thead>
        <tbody>
          {appointments.map((a) => (
            <tr key={a.id} className="border-b">
              <td className="px-4 py-2">{a.doctor?.name ?? "—"}</td>
              <td className="px-4 py-2">{a.patient?.name ?? "—"}</td>
              <td className="px-4 py-2">
                {new Date(a.scheduled_time).toLocaleString("pt-BR")}
              </td>
              <td className="px-4 py-2">
                {a.status === "PENDING"
                  ? "⚪ Pendente"
                  : a.status === "CHECKED_IN"
                  ? "🟢 Confirmado"
                  : a.status === "CANCELLED"
                  ? "🔴 Cancelado"
                  : "🟡 Ausente"}
              </td>
              <td className="px-4 py-2 flex gap-2">
                <button
                  onClick={() => startEdit(a)}
                  className="bg-blue-500 text-white px-3 py-1 rounded text-sm hover:bg-blue-600"
                >
                  Editar
                </button>
                <button
                  onClick={() => deleteAppointment(a.id)}
                  className="bg-red-500 text-white px-3 py-1 rounded text-sm hover:bg-red-600"
                >
                  Cancelar
                </button>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}
