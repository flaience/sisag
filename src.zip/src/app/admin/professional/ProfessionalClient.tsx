"use client";

import { useState } from "react";
import DoctorsTable, { Doctor } from "./components/DoctorsTable";
import DoctorsDialog from "./components/DoctorsDialog";
import { DoctorFormData } from "./schema";

export default function DoctorsClient() {
  const [open, setOpen] = useState(false);
  const [editing, setEditing] = useState<DoctorFormData | null>(null);
  const [refreshKey, setRefreshKey] = useState(0);

  function handleNew() {
    setEditing(null);
    setOpen(true);
  }

  function onSaved() {
    setRefreshKey((k) => k + 1);
  }

  return (
    <div key={String(refreshKey)}>
      <div className="mb-4 flex items-center justify-between">
        <h2 className="text-lg font-semibold">Médicos</h2>

        <button
          onClick={handleNew}
          className="bg-primary text-white px-4 py-2 rounded"
        >
          Novo médico
        </button>
      </div>

      <DoctorsTable
        onEdit={(d: Doctor) => {
          setEditing({
            id: d.id,
            name: d.name,
            specialty: d.specialty,
            photo_url: d.photo_url ?? null,
            status: (d.status ?? "ACTIVE") as "ACTIVE" | "INACTIVE",
            avg_duration: d.avg_duration ?? 20,
          });
          setOpen(true);
        }}
      />

      <DoctorsDialog
        open={open}
        editing={editing}
        onOpenChange={setOpen}
        onSaved={onSaved}
      />
    </div>
  );
}
