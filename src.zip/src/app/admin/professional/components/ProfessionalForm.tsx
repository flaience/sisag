// src/app/admin/doctors/components/DoctorsForm.tsx
"use client";

import { zodResolver } from "@hookform/resolvers/zod";
import { useForm, Controller } from "react-hook-form";
import { DoctorSchema, DoctorFormData } from "../schema";
import { toast } from "sonner";
import { useEffect, useState } from "react";
import { createDoctor, updateDoctor } from "../actions/doctor-actions";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";

/**
 * Esta versão usa Controller do react-hook-form para evitar problemas
 * de tipos com wrappers/form components customizados.
 */

interface Props {
  initial?: DoctorFormData | null;
  onSaved: () => void;
  onClose: () => void;
}

export default function DoctorsForm({ initial, onSaved, onClose }: Props) {
  const [uploading, setUploading] = useState(false);

  const form = useForm<DoctorFormData>({
    resolver: zodResolver(DoctorSchema) as any, // 'as any' protege contra assinaturas de tipo divergentes
    defaultValues: initial ?? {
      name: "",
      specialty: "",
      photo_url: null,
      status: "ACTIVE",
      avg_duration: 20,
    },
  });

  const { handleSubmit, control, reset } = form;

  useEffect(() => {
    if (initial) {
      // garantir formato consistente: nunca undefined para status/avg_duration
      reset({
        id: initial.id,
        name: initial.name ?? "",
        specialty: initial.specialty ?? "",
        photo_url: initial.photo_url ?? null,
        status: (initial.status ?? "ACTIVE") as "ACTIVE" | "INACTIVE",
        avg_duration: initial.avg_duration ?? 20,
      });
    }
  }, [initial, reset]);

  async function onSubmit(values: DoctorFormData) {
    try {
      // normalizar antes do envio
      const payload = {
        ...values,
        photo_url: values.photo_url ?? null,
        avg_duration: values.avg_duration ?? 20,
        status: values.status ?? "ACTIVE",
      };

      if (payload.id) {
        await updateDoctor(payload);
        toast.success("Médico atualizado com sucesso");
      } else {
        await createDoctor(payload);
        toast.success("Médico criado com sucesso");
      }
      onSaved();
      onClose();
    } catch (err) {
      console.error(err);
      toast.error("Erro ao salvar médico");
    }
  }

  // upload via form POST para /api/admin/doctors/upload
  async function handleFile(e: React.ChangeEvent<HTMLInputElement>) {
    const file = e.target.files?.[0];
    if (!file) return;
    setUploading(true);
    try {
      const fd = new FormData();
      fd.append("file", file);
      const res = await fetch("/api/admin/doctors/upload", {
        method: "POST",
        body: fd,
      });
      const json = await res.json();
      if (!res.ok) throw new Error(json?.error || "Upload falhou");
      // atualiza o campo photo_url
      form.setValue("photo_url", json.url);
      toast.success("Foto enviada");
    } catch (err) {
      console.error(err);
      toast.error("Erro no upload");
    } finally {
      setUploading(false);
    }
  }

  return (
    <form onSubmit={handleSubmit(onSubmit)} className="space-y-4">
      {/* Nome */}
      <Controller
        control={control}
        name="name"
        render={({ field, fieldState }) => (
          <div>
            <label className="block text-sm font-medium mb-1">Nome</label>
            <Input {...field} value={field.value ?? ""} />
            {fieldState.error && (
              <p className="text-sm text-red-600 mt-1">
                {fieldState.error.message}
              </p>
            )}
          </div>
        )}
      />

      {/* Especialidade */}
      <Controller
        control={control}
        name="specialty"
        render={({ field, fieldState }) => (
          <div>
            <label className="block text-sm font-medium mb-1">
              Especialidade
            </label>
            <Input {...field} value={field.value ?? ""} />
            {fieldState.error && (
              <p className="text-sm text-red-600 mt-1">
                {fieldState.error.message}
              </p>
            )}
          </div>
        )}
      />

      {/* Duração média */}
      <Controller
        control={control}
        name="avg_duration"
        render={({ field, fieldState }) => (
          <div>
            <label className="block text-sm font-medium mb-1">
              Duração média (min)
            </label>
            <Input type="number" {...field} value={String(field.value ?? 20)} />
            {fieldState.error && (
              <p className="text-sm text-red-600 mt-1">
                {fieldState.error.message}
              </p>
            )}
          </div>
        )}
      />

      {/* Foto */}
      <Controller
        control={control}
        name="photo_url"
        render={({ field }) => (
          <div>
            <label className="block text-sm font-medium mb-1">Foto</label>
            <div className="flex items-center gap-3">
              <img
                src={field.value ?? "/avatar-placeholder.png"}
                alt="avatar"
                className="w-16 h-16 rounded-full object-cover border"
              />
              <div>
                <input
                  type="file"
                  accept="image/*"
                  onChange={handleFile}
                  disabled={uploading}
                />
                <div className="text-sm text-gray-500">
                  {uploading ? "Enviando..." : "PNG/JPG até 2MB"}
                </div>
              </div>
            </div>
          </div>
        )}
      />

      {/* Status */}
      <Controller
        control={control}
        name="status"
        render={({ field }) => (
          <div>
            <label className="block text-sm font-medium mb-1">Status</label>
            <select {...field} className="border p-2 rounded w-full">
              <option value="ACTIVE">Ativo</option>
              <option value="INACTIVE">Inativo</option>
            </select>
          </div>
        )}
      />

      <div className="flex justify-end gap-2 pt-2">
        <Button type="button" variant="outline" onClick={onClose}>
          Cancelar
        </Button>
        <Button type="submit">Salvar</Button>
      </div>
    </form>
  );
}
