"use client";

import { useEffect, useState } from "react";
import { listProfessionals, deleteProfessional } from "../actions/-actions";
import { toast } from "sonner";

export interface Professional {
  id: string;
  name: string;
  specialty: string;
  photo_url?: string | null;
  status?: "ACTIVE" | "INACTIVE" | null;
  avg_duration?: number | null;
}

export default function ProfessionalTable({
  onEdit,
}: {
  onEdit: (d: Professional) => void;
}) {
  const [items, setItems] = useState<Professional[]>([]);
  const [loading, setLoading] = useState(false);
  const [page, setPage] = useState(1);
  const [total, setTotal] = useState(0);
  const [search, setSearch] = useState("");

  async function load() {
    setLoading(true);
    try {
      const data = await listProfessionals({ page, limit: 10, search });
      setItems(data.items);
      setTotal(data.total);
    } catch (err) {
      console.error(err);
      toast.error("Erro ao carregar médicos");
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => {
    load();
  }, [page, search]);

  async function handleDelete(id: string) {
    if (!confirm("Confirmar exclusão do médico?")) return;
    try {
      await deleteProfessional(id);
      toast.success("Médico removido");
      load();
    } catch (err) {
      toast.error("Erro ao remover médico");
      console.error(err);
    }
  }

  const totalPages = Math.max(1, Math.ceil(total / 10));

  return (
    <div className="bg-white p-4 rounded-xl shadow">
      <div className="flex items-center gap-2 mb-4">
        <input
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          placeholder="Buscar por nome / especialidade"
          className="border p-2 rounded flex-1"
        />
        <button
          onClick={() => {
            setPage(1);
            load();
          }}
          className="bg-primary text-white px-4 py-2 rounded"
        >
          Buscar
        </button>
      </div>

      {loading ? (
        <div className="p-8 text-center">Carregando...</div>
      ) : (
        <table className="w-full">
          <thead className="bg-gray-100">
            <tr>
              <th className="px-4 py-2 text-left">Médico</th>
              <th className="px-4 py-2 text-left">Especialidade</th>
              <th className="px-4 py-2 text-left">Duração (min)</th>
              <th className="px-4 py-2 text-left">Status</th>
              <th className="px-4 py-2 text-right">Ações</th>
            </tr>
          </thead>

          <tbody>
            {items.length === 0 && (
              <tr>
                <td colSpan={5} className="py-6 text-center text-gray-500">
                  Nenhum médico encontrado.
                </td>
              </tr>
            )}

            {items.map((d) => (
              <tr key={d.id} className="border-b">
                <td className="px-4 py-2 flex items-center gap-3">
                  <img
                    src={d.photo_url ?? "/avatar-placeholder.png"}
                    className="w-10 h-10 rounded-full object-cover border"
                    alt={d.name}
                  />
                  <div>
                    <div className="font-medium">{d.name}</div>
                    <div className="text-sm text-gray-500">{d.specialty}</div>
                  </div>
                </td>

                <td className="px-4 py-2">{d.specialty}</td>

                <td className="px-4 py-2">{d.avg_duration ?? 20}</td>

                <td className="px-4 py-2">
                  <span
                    className={`px-2 py-1 rounded text-sm ${
                      (d.status ?? "ACTIVE") === "ACTIVE"
                        ? "bg-green-100 text-green-700"
                        : "bg-gray-200 text-gray-700"
                    }`}
                  >
                    {(d.status ?? "ACTIVE") === "ACTIVE" ? "Ativo" : "Inativo"}
                  </span>
                </td>

                <td className="px-4 py-2 text-right">
                  <button
                    onClick={() => onEdit(d)}
                    className="px-3 py-1 border rounded mr-2"
                  >
                    Editar
                  </button>

                  <button
                    onClick={() => handleDelete(d.id)}
                    className="px-3 py-1 bg-red-600 text-white rounded"
                  >
                    Excluir
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      )}

      <div className="flex items-center justify-between mt-4">
        <div className="text-sm text-gray-600">
          Página {page} de {totalPages} ({total} itens)
        </div>

        <div className="flex gap-2">
          <button
            onClick={() => setPage((p) => Math.max(1, p - 1))}
            disabled={page === 1}
            className="px-3 py-1 border rounded disabled:opacity-50"
          >
            Anterior
          </button>

          <button
            onClick={() => setPage((p) => Math.min(totalPages, p + 1))}
            disabled={page >= totalPages}
            className="px-3 py-1 border rounded disabled:opacity-50"
          >
            Próxima
          </button>
        </div>
      </div>
    </div>
  );
}
