import { z } from "zod";

export const DoctorSchema = z.object({
  id: z.string().uuid().optional(),
  name: z.string().min(1, "O nome é obrigatório"),
  specialty: z.string().min(1, "A especialidade é obrigatória"),
  photo_url: z.string().nullable().optional(),
  status: z.enum(["ACTIVE", "INACTIVE"]).optional().default("ACTIVE"),
  avg_duration: z.number().min(5).optional().default(20),
});

export type DoctorFormData = z.infer<typeof DoctorSchema>;
