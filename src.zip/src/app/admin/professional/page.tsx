// src/app/admin/doctors/page.tsx
import dynamic from "next/dynamic";

const DoctorsClient = dynamic(() => import("./DoctorsClient"), { ssr: false });

export default function DoctorsPage() {
  return (
    <div>
      <h1 className="text-2xl font-bold text-primary mb-6">Médicos</h1>
      <DoctorsClient />
    </div>
  );
}
